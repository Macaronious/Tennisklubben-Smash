// Egen Exceptions
class UgyldigAlderException extends Exception {
    public UgyldigAlderException(String message) {
        super(message);
    }
}
