public class BetalingsException extends Exception {
    public BetalingsException(String message) {
        super(message);
    }
}
