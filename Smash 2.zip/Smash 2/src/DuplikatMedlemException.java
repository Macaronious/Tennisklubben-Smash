class DuplikatMedlemException extends Exception {
    public DuplikatMedlemException(String message) {
        super(message);
    }
}