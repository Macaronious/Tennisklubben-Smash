// ---------------------------
// Enums
// ---------------------------
enum Enums {SINGLE, DOUBLE, MIXED_DOUBLE;
    
    enum MedlemsType {ACTIVE, PASSIVE}
}
