import java.io.IOException;



interface Persistens {
    void gem(String mappe) throws IOException;

    void indlaes(String mappe) throws IOException;
}
